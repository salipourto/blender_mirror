#pragma once
#include <hiprt/impl/Aabb.h>
#include <hiprt/impl/Ray.h>

namespace hiprt
{
class Triangle
{
  public:
	HIPRT_HOST_DEVICE Triangle() = default;

	HIPRT_HOST_DEVICE Triangle( const float3& v0, const float3& v1, const float3& v2 ) : m_v0( v0 ), m_v1( v1 ), m_v2( v2 ) {}

	HIPRT_HOST_DEVICE Aabb aabb() const
	{
		Aabb aabb;
		return aabb.grow( m_v0 ).grow( m_v1 ).grow( m_v2 );
	}

	HIPRT_HOST_DEVICE float3 center() const { return ( m_v0 + m_v1 + m_v2 ) / 3.0f; }

	HIPRT_HOST_DEVICE float area() const
	{
		float3 c = cross( m_v2 - m_v0, m_v1 - m_v0 );
		return sqrt( dot( c, c ) ) * 0.5f;
	}

	HIPRT_HOST_DEVICE float3 normal() const { return cross( m_v1 - m_v0, m_v2 - m_v0 ); }

	HIPRT_HOST_DEVICE
	bool intersect( const Ray& ray, float2& uv, float& t ) const
	{
		float3 e1 = m_v1 - m_v0;
		float3 e2 = m_v2 - m_v0;
		float3 s1 = cross( ray.m_direction, e2 );

		float denom = dot( s1, e1 );

		if ( denom == 0.f ) return false;

		float  invd = 1.0f / denom;
		float3 d	= ray.m_origin - m_v0;
		float  b1	= dot( d, s1 ) * invd;

		float3 s2 = cross( d, e1 );
		float  b2 = dot( ray.m_direction, s2 ) * invd;

		float temp = dot( e2, s2 ) * invd;

		if ( ( b1 < 0.f ) || ( b1 > 1.f ) || ( b2 < 0.f ) || ( b1 + b2 > 1.f ) || ( temp < 0.0f ) || ( temp > ray.m_maxT ) )
		{
			return false;
		}
		else
		{
			uv.x = b1;
			uv.y = b2;
			t	 = temp;
			return true;
		}
	}

	HIPRT_HOST_DEVICE void split( int axis, float position, const Aabb& box, Aabb& leftBox, Aabb& rightBox )
	{
		leftBox = rightBox = Aabb();

		const float3* vertices = (float3*)&m_v0;
		const float3* v1	   = &vertices[2];

		for ( int i = 0; i < 3; i++ )
		{
			const float3* v0 = v1;
			v1				 = &vertices[i];
			float v0p		 = ( (float*)v0 )[axis];
			float v1p		 = ( (float*)v1 )[axis];

			if ( v0p <= position ) leftBox.grow( *v0 );
			if ( v0p >= position ) rightBox.grow( *v0 );

			if ( ( v0p < position && v1p > position ) || ( v0p > position && v1p < position ) )
			{
				float3 t = mix( *v0, *v1, clamp( ( position - v0p ) / ( v1p - v0p ), 0.0f, 1.0f ) );
				leftBox.grow( t );
				rightBox.grow( t );
			}
		}

		( (float*)&leftBox.m_max )[axis]  = position;
		( (float*)&rightBox.m_min )[axis] = position;
		leftBox.intersect( box );
		rightBox.intersect( box );
	}

  public:
	float3 m_v0;
	float3 m_v1;
	float3 m_v2;
};
} // namespace hiprt
