#pragma once
#include <hiprt/impl/Aabb.h>
#include <hiprt/impl/Triangle.h>

#define LOG_BVH_COST 0

namespace hiprt
{
static constexpr u32 NodeAlignment = 64u;

static constexpr float Ci = 2.0f;
static constexpr float Ct = 3.0f;

enum
{
	TriangleType = 0,
	BoxType		 = 5,
	InstanceType = 6,
	CustomType	 = 7
};

enum
{
	RootIndex = BoxType
};

HIPRT_HOST_DEVICE HIPRT_INLINE static int getNodeType( int nodeIndex ) { return ( nodeIndex & 7 ); }

HIPRT_HOST_DEVICE HIPRT_INLINE static int getNodeAddr( int nodeIndex )
{
	return nodeIndex >> ( getNodeType( nodeIndex ) == BoxType ? 4 : 3 );
}

HIPRT_HOST_DEVICE HIPRT_INLINE static int encodeNodeIndex( int nodeAddr, int nodeType )
{
	if ( nodeType == BoxType ) nodeAddr *= 2;
	return ( nodeAddr << 3 ) | nodeType;
}

HIPRT_HOST_DEVICE HIPRT_INLINE static u64 encodeBaseAddr( const void* baseAddr, int nodeIndex )
{
	u64 baseIndex = ( (u64)baseAddr ) >> 3ull;
	return baseIndex + nodeIndex;
}

HIPRT_HOST_DEVICE HIPRT_INLINE static bool isLeafNode( int nodeIndex )
{
	return getNodeType( nodeIndex ) != BoxType && nodeIndex != HIPRT_INVALID_VALUE;
}

HIPRT_HOST_DEVICE HIPRT_INLINE static bool isInternalNode( int nodeIndex ) { return getNodeType( nodeIndex ) == BoxType; }

// 32B
class HIPRT_ALIGN( NodeAlignment ) ScratchNode
{
  public:
	int	 m_childIndex0;
	int	 m_childIndex1;
	Aabb m_box;

	HIPRT_HOST_DEVICE Aabb aabb() const { return m_box; };

	HIPRT_HOST_DEVICE float area() const { return aabb().area(); }

	HIPRT_HOST_DEVICE int getChildType( int i ) const { return getNodeType( ( &m_childIndex0 )[i] ); }

	HIPRT_HOST_DEVICE int getChildIndex( int i ) const { return ( &m_childIndex0 )[i]; }

	HIPRT_HOST_DEVICE int getChildAddr( int i ) const { return getNodeAddr( ( &m_childIndex0 )[i] ); }

	HIPRT_HOST_DEVICE void encodeChildIndex( int i, int childAddr, int nodeType )
	{
		( &m_childIndex0 )[i] = encodeNodeIndex( childAddr, nodeType );
	}
};

// 128B
class HIPRT_ALIGN( NodeAlignment ) BoxNode
{
  public:
	int	 m_childIndex0;
	int	 m_childIndex1;
	int	 m_childIndex2;
	int	 m_childIndex3;
	Aabb m_box0;
	Aabb m_box1;
	Aabb m_box2;
	Aabb m_box3;
	int	 m_parentAddr;
	int	 m_updateCounter;
	int	 m_childCount;

	HIPRT_HOST_DEVICE BoxNode()
		: m_childIndex0( HIPRT_INVALID_VALUE ), m_childIndex1( HIPRT_INVALID_VALUE ), m_childIndex2( HIPRT_INVALID_VALUE ),
		  m_childIndex3( HIPRT_INVALID_VALUE ), m_parentAddr( HIPRT_INVALID_VALUE ), m_updateCounter( 0 ), m_childCount( 2 )
	{
	}

	HIPRT_HOST_DEVICE Aabb aabb() const
	{
		Aabb aabb;
		if ( m_childIndex0 != HIPRT_INVALID_VALUE ) aabb.grow( m_box0 );
		if ( m_childIndex1 != HIPRT_INVALID_VALUE ) aabb.grow( m_box1 );
		if ( m_childIndex2 != HIPRT_INVALID_VALUE ) aabb.grow( m_box2 );
		if ( m_childIndex3 != HIPRT_INVALID_VALUE ) aabb.grow( m_box3 );
		return aabb;
	}

	HIPRT_HOST_DEVICE float area() const { return aabb().area(); }

	HIPRT_HOST_DEVICE int getChildType( int i ) const { return getNodeType( ( &m_childIndex0 )[i] ); }

	HIPRT_HOST_DEVICE int getChildAddr( int i ) const { return getNodeAddr( ( &m_childIndex0 )[i] ); }

	HIPRT_HOST_DEVICE void encodeChildIndex( int i, int childAddr, int nodeType )
	{
		( &m_childIndex0 )[i] = encodeNodeIndex( childAddr, nodeType );
	}

	HIPRT_HOST_DEVICE Aabb getChildBox( int i ) { return (&m_box0)[i]; }

	HIPRT_HOST_DEVICE void setChildBox( int i, const Aabb& box ) { ( &m_box0 )[i] = box; }
};
static_assert( sizeof( BoxNode ) == 128 );

// 64B
class HIPRT_ALIGN( NodeAlignment ) TriangleNode
{
  public:
	Triangle m_triangle;
	int		 pad[4];
	int		 m_parentAddr;
	int		 m_primIndex;
	int		 m_flags;

	HIPRT_HOST_DEVICE TriangleNode() : m_parentAddr( HIPRT_INVALID_VALUE ), m_primIndex( HIPRT_INVALID_VALUE ) {}

	HIPRT_HOST_DEVICE Aabb aabb() const { return m_triangle.aabb(); }

	HIPRT_HOST_DEVICE float area() const { return aabb().area(); }
};
static_assert( sizeof( TriangleNode ) == 64 );

// 64B
class HIPRT_ALIGN( NodeAlignment ) CustomNode
{
  public:
	Aabb m_box;
	int	 m_primIndex;
	int	 m_parentAddr;

	HIPRT_HOST_DEVICE CustomNode() : m_parentAddr( HIPRT_INVALID_VALUE ), m_primIndex( HIPRT_INVALID_VALUE ) {}

	HIPRT_HOST_DEVICE Aabb aabb() const { return m_box; }

	HIPRT_HOST_DEVICE float area() const { return m_box.area(); }
};
static_assert( sizeof( CustomNode ) == 64 );

// 64B
class HIPRT_ALIGN( NodeAlignment ) InstanceNode
{
  public:
	Aabb m_box;
	int	 m_primIndex;
	int	 m_parentAddr;
	u32	 m_mask;
	u32	 m_frameIndex;
	u32	 m_frameCount;

	HIPRT_HOST_DEVICE InstanceNode()
		: m_parentAddr( HIPRT_INVALID_VALUE ), m_primIndex( HIPRT_INVALID_VALUE ), m_mask( HIPRT_INVALID_VALUE ),
		  m_frameIndex( HIPRT_INVALID_VALUE ), m_frameCount( HIPRT_INVALID_VALUE ) {}

	HIPRT_HOST_DEVICE Aabb aabb() const { return m_box; }

	HIPRT_HOST_DEVICE float area() const { return m_box.area(); }
};
static_assert( sizeof( InstanceNode ) == 64 );

// 32B
struct ReferenceNode
{
	HIPRT_HOST_DEVICE ReferenceNode( u32 primIndex ) : m_primIndex( primIndex ) {}

	HIPRT_HOST_DEVICE ReferenceNode( u32 primIndex, const Aabb& box ) : m_primIndex( primIndex ), m_box( box ) {}

	HIPRT_HOST_DEVICE Aabb aabb() const { return m_box; };

	Aabb m_box;
	int	 m_primIndex;
	int	 m_parentAddr;
};
static_assert( sizeof( ReferenceNode ) == 32 );

// 64B
class HIPRT_ALIGN( NodeAlignment ) ApiNode
{
  public:
	u32	 m_childIndices[4];
	u32	 m_leafFlags[4];
	Aabb m_box;

	HIPRT_HOST_DEVICE ApiNode() {}

	HIPRT_HOST_DEVICE Aabb aabb() const { return m_box; }

	HIPRT_HOST_DEVICE float area() const { return m_box.area(); }
};
static_assert( sizeof( ApiNode ) == 64 );
} // namespace hiprt
