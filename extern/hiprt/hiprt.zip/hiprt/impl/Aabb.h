#pragma once
#include <hiprt/impl/Math.h>

namespace hiprt
{
class Aabb
{
public:
    HIPRT_HOST_DEVICE Aabb()
    {
        reset();
    }
    
    HIPRT_HOST_DEVICE Aabb(const float3& p) : m_min(p), m_max(p) {}
    
    HIPRT_HOST_DEVICE Aabb(const float3& mi, const float3& ma) : m_min(mi), m_max(ma) {}
    
    HIPRT_HOST_DEVICE Aabb(const Aabb& rhs, const Aabb& lhs) 
    {
        m_min = min(lhs.m_min, rhs.m_min);
        m_max = max(lhs.m_max, rhs.m_max);
    }

    HIPRT_HOST_DEVICE Aabb(const Aabb& rhs) : m_min(rhs.m_min), m_max(rhs.m_max) {}

    HIPRT_HOST_DEVICE void reset(void)
    {
        m_min = make_float3(FLT_MAX);
        m_max = make_float3(-FLT_MAX);
    }

    HIPRT_HOST_DEVICE Aabb& grow(const Aabb& rhs)
    {
        m_min = min(m_min, rhs.m_min);
        m_max = max(m_max, rhs.m_max);
        return *this;
    }
    
    HIPRT_HOST_DEVICE Aabb& grow(const float3& p)
    {
        m_min = min(m_min, p);
        m_max = max(m_max, p);
        return *this;
    }

    HIPRT_HOST_DEVICE float3 center() const { return (m_max + m_min) * 0.5f; }

    HIPRT_HOST_DEVICE float3 extent() const { return m_max - m_min; }
    
    HIPRT_HOST_DEVICE float area() const
    {
        float3 ext = extent();
        return 2 * (ext.x * ext.y + ext.x * ext.z + ext.y * ext.z);
    }

    HIPRT_HOST_DEVICE void intersect( const Aabb& box )
	{
		m_min = max( m_min, box.m_min );
		m_max = min( m_max, box.m_max );
	}

    HIPRT_HOST_DEVICE float2 intersect(
        const float3& invD,
        const float3& oxInvD,
        float         maxT
    ) const
    {
        float3 f = fma(m_max, invD, oxInvD);
        float3 n = fma(m_min, invD, oxInvD);
        float3 tmax = max(f, n);
        float3 tmin = min(f, n);
        float  t1 = fminf(fminf(fminf(tmax.x, tmax.y), tmax.z), maxT);
        float  t0 = fmaxf(fmaxf(fmaxf(tmin.x, tmin.y), tmin.z), 0.0f);
        return make_float2(t0, t1);
    }

#if defined(__KERNELCC__)
    HIPRT_DEVICE void atomicGrow(const Aabb& aabb)
    {
        atomicMinFloat(&m_min.x, aabb.m_min.x);
        atomicMinFloat(&m_min.y, aabb.m_min.y);
        atomicMinFloat(&m_min.z, aabb.m_min.z);
        atomicMaxFloat(&m_max.x, aabb.m_max.x);
        atomicMaxFloat(&m_max.y, aabb.m_max.y);
        atomicMaxFloat(&m_max.z, aabb.m_max.z);
    }

    HIPRT_DEVICE void atomicGrow( const float3& p )
	{
		atomicMinFloat( &m_min.x, p.x );
		atomicMinFloat( &m_min.y, p.y );
		atomicMinFloat( &m_min.z, p.z );
		atomicMaxFloat( &m_max.x, p.x );
		atomicMaxFloat( &m_max.y, p.y );
		atomicMaxFloat( &m_max.z, p.z );
	}
#endif

public:
    float3 m_min;
    float3 m_max;
};
}
