#pragma once
#include <hiprt/impl/Math.h>

namespace hiprt
{
class HIPRT_ALIGN( 32 ) Ray
{
public:
    HIPRT_HOST_DEVICE Ray(void) : m_time(0.0f), m_maxT(0.0f)
    {
        m_origin = make_float3(0.0f);
        m_direction = make_float3(0.0f);
    }

    HIPRT_HOST_DEVICE Ray(const float3& origin, const float3& direction)
        : m_time(0.0f), m_maxT(0.0f)
    {
        m_origin = origin;
        m_direction = direction;
    }

public:
    float3 m_origin;
    float  m_time;
    float3 m_direction;
    float  m_maxT;
};
static_assert( sizeof( Ray ) == 32 );
}
