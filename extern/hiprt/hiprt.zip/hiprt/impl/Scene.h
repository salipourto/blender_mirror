#pragma once
#include <hiprt/impl/Common.h>
#include <hiprt/impl/Transform.h>

namespace hiprt
{
struct SceneHeader
{
	BoxNode*	  m_boxNodes;
	InstanceNode* m_primNodes;
	GeomHeader**  m_geoms;
	Frame*		  m_frames;
	size_t		  m_size;
};
} // namespace hiprt
