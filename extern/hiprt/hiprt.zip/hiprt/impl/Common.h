#pragma once

#if (defined(__CUDACC__) || defined(__HIPCC__))
#define __KERNELCC__
#endif

#if !defined(__KERNELCC__)
#include <algorithm>
#include <cfloat>
#include <cstring>
#include <cmath>
#include <map>
#include <string>
#include <vector>
#include <fstream>
#include <iostream>
#include <type_traits>

#define __host__
#define __device__

#else
#define FLT_MAX 3.402823466e+38F
#define INT_MAX 2147483647
#endif

// FIXME: __align__(N) works in HIP using driver 22.10.
#if defined( __CUDACC__ )
#define HIPRT_ALIGN(N) __align__(N)
#elif defined(__GNUC__)
#define HIPRT_ALIGN(N) __attribute__((aligned(N)))
#elif defined( _MSC_VER ) || defined( __HIPCC__ )
#define HIPRT_ALIGN(N) __declspec(align(N))
#else
#error "Please provide a definition for HIPRT_ALIGN!!"
#endif

#define HIPRT_INVALID_VALUE (0xFFFFFFFF)

#ifdef __CUDACC__
#define HIPRT_INLINE __forceinline__
#else
#define HIPRT_INLINE inline
#endif
#define HIPRT_HOST __host__
#define HIPRT_DEVICE __device__
#define HIPRT_HOST_DEVICE __host__ __device__

#define HIPRT_MIN( a, b ) ( ( ( b ) < ( a ) ) ? ( b ) : ( a ) )
#define HIPRT_MAX( a, b ) ( ( ( b ) > ( a ) ) ? ( b ) : ( a ) )

#ifndef M_PI
#define M_PI 3.14159265358
#endif

typedef unsigned long long u64;
typedef unsigned int	   u32;
typedef unsigned short	   u16;
typedef unsigned char	   u8;

namespace hiprt
{
template <typename T>
HIPRT_HOST_DEVICE HIPRT_INLINE void swap( T& a, T& b )
{
	T t = a;
	a = b;
	b = t;
}

#if defined(__KERNELCC__)
template <class T, class U>
struct is_same 
{
    enum { value = 0 };
};

template <class T>
struct is_same<T, T> 
{
    enum { value = 1 };
};

template <bool B, class T, class F>
struct conditional
{
	typedef T type;
};

template <class T, class F>
struct conditional<false, T, F>
{
	typedef F type;
};
#endif

#if !defined(__KERNELCC__)
template <typename T>
struct Traits
{
    static const std::string TYPE_NAME;
};

#define DECLARE_TYPE_TRAITS(name) template <> const std::string Traits<name>::TYPE_NAME = #name;
#endif
}
