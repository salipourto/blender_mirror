#pragma once
#include <hiprt/impl/Aabb.h>
#include <hiprt/impl/QrDecomposition.h>
#include <hiprt/impl/Ray.h>

namespace hiprt
{
struct HIPRT_ALIGN( 64 ) Frame
{
	HIPRT_HOST_DEVICE float3 transform( const float3& p ) const
	{
		if ( identity() ) return p;
		float3 result = p;
		result *= m_scale;
		result += make_float3( p.y * m_shear.x + p.z * m_shear.y, p.z * m_shear.z, 0.0f );
		result = qtRotate( m_rotation, result );
		result += m_translation;
		return result;
	}

	HIPRT_HOST_DEVICE float3 transformVector( const float3& v ) const
	{
		if ( identity() ) return v;
		float3 result = v;
		result /= m_scale;
		result.y -= v.x * m_shear.x / m_scale.y;
		result.z -= ( m_shear.y * result.x + m_shear.z * result.y ) / m_scale.z;
		result = qtRotate( m_rotation, result );
		return result;
	}

	HIPRT_HOST_DEVICE float3 invTransform( const float3& p ) const
	{
		if ( identity() ) return p;
		float3 result = p;
		result -= m_translation;
		result = qtInvRotate( m_rotation, result );
		result /= m_scale;
		result.y -= p.z * m_shear.z / m_scale.y;
		result.x -= ( m_shear.x * result.y + m_shear.y * result.z ) / m_scale.x;
		return result;
	}

	HIPRT_HOST_DEVICE float3 invTransformVector( const float3& v ) const
	{
		if ( identity() ) return v;
		float3 result = v;
		result = qtInvRotate( m_rotation, result );
		result *= m_scale;
		result += make_float3( 0.0f, v.x * m_shear.x, v.x * m_shear.y + v.y * m_shear.z );
		return result;
	}

	HIPRT_HOST_DEVICE bool identity() const
	{ 
		if ( m_scale.x != 1.0f || m_scale.y != 1.0f || m_scale.z != 1.0f ) return false;
		if ( m_shear.x != 0.0f || m_shear.y != 0.0f || m_shear.z != 0.0f ) return false;
		if ( m_translation.x != 0.0f || m_translation.y != 0.0f || m_translation.z != 0.0f ) return false;
		if ( m_rotation.w != 0.0f ) return false;
		return true;
	}

	float4 m_rotation;
	float3 m_scale;
	float3 m_shear;
	float3 m_translation;
	float  m_time;
};
static_assert( sizeof( Frame ) == 64 );

struct HIPRT_ALIGN( 16 ) SRTFrame
{
	float4 m_rotation;
	float3 m_scale;
	float3 m_translation;
	float  m_time;

	HIPRT_HOST_DEVICE Frame convert() const 
	{
		Frame frame;
		frame.m_time		= m_time;
		frame.m_rotation	= qtFromAxisAngle( m_rotation );
		frame.m_scale		= m_scale;
		frame.m_shear		= make_float3( 0.0f );
		frame.m_translation = m_translation;
		return frame;
	}
};
static_assert( sizeof( SRTFrame ) == 48 );

struct HIPRT_ALIGN( 64 ) MatrixFrame
{
	float m_matrix[3][4];
	float m_time;

	HIPRT_HOST_DEVICE Frame convert() const 
	{ 
		float QR[3][3], Q[3][3], R[3][3];
		#pragma unroll
		for (int i = 0; i < 3; ++i)
			#pragma unroll
			for ( int j = 0; j < 3; ++j )
				QR[i][j] = m_matrix[i][j];
		qr( &QR[0][0], &Q[0][0], &R[0][0] );

		Frame frame;
		frame.m_time		= m_time;
		frame.m_translation = make_float3( m_matrix[0][3], m_matrix[1][3], m_matrix[2][3] );
		frame.m_rotation	= qtFromRotationMatrix( Q );
		frame.m_scale		= make_float3( R[0][0], R[1][1], R[2][2] );
		frame.m_shear		= make_float3( R[0][1], R[0][2], R[1][2] );
		return frame; 
	}
};
static_assert( sizeof( MatrixFrame ) == 64 );

class Transform
{
  public:
	HIPRT_HOST_DEVICE Transform( const Frame* frameData, u32 frameCount ) : m_frames( frameData ), m_frameCount( frameCount ) {}

	HIPRT_HOST_DEVICE Frame interpolateFrames( float time )
	{
		Frame f0 = m_frames[0];
		if ( m_frameCount == 1 || time <= f0.m_time ) return f0;

		Frame f1 = m_frames[m_frameCount - 1];
		if ( time >= f1.m_time ) return f1;

		for ( int i = 1; i < m_frameCount; ++i )
		{
			f1 = m_frames[i];
			if ( time >= f0.m_time && time <= f1.m_time ) break;
			f0 = f1;
		}

		float t = ( time - f0.m_time ) / ( f1.m_time - f0.m_time );

		Frame f;
		f.m_scale		= mix( f0.m_scale, f1.m_scale, t );
		f.m_shear		= mix( f0.m_shear, f1.m_shear, t );
		f.m_translation = mix( f0.m_translation, f1.m_translation, t );
		f.m_rotation	= qtMix( f0.m_rotation, f1.m_rotation, t );

		return f;
	}

	HIPRT_HOST_DEVICE Ray transformRay( const Ray& ray )
	{
		Ray	  outRay;
		Frame frame		   = interpolateFrames( ray.m_time );
		if ( frame.identity() ) return ray;
		outRay.m_origin	   = frame.invTransform( ray.m_origin );
		outRay.m_direction = frame.invTransform( ray.m_origin + ray.m_direction );
		outRay.m_direction = outRay.m_direction - outRay.m_origin;
		outRay.m_time	   = ray.m_time;
		outRay.m_maxT	   = ray.m_maxT;
		return outRay;
	}

	HIPRT_HOST_DEVICE float3 transformNormal( const float3& normal, float time )
	{
		Frame frame = interpolateFrames( time );
		return frame.transformVector( normal );
	}

	HIPRT_HOST_DEVICE Aabb boundPointMotion( const float3& p )
	{
		Aabb outAabb;

		Frame f0 = m_frames[0];
		outAabb.grow( f0.transform( p ) );
		if ( m_frameCount == 1 ) return outAabb;

		const u32	steps = 3;
		const float delta = 1.0f / float( steps + 1 );

		Frame f1;
		for ( int i = 1; i < m_frameCount; ++i )
		{
			f1		= m_frames[i];
			float t = delta;
			for ( int j = 1; j <= steps; ++j )
			{
				Frame f;
				f.m_scale		= mix( f0.m_scale, f1.m_scale, t );
				f.m_shear		= mix( f0.m_shear, f1.m_shear, t );
				f.m_translation = mix( f0.m_translation, f1.m_translation, t );
				f.m_rotation	= qtMix( f0.m_rotation, f1.m_rotation, t );
				outAabb.grow( f.transform( p ) );
				t += delta;
			}
			f0 = f1;
			outAabb.grow( f0.transform( p ) );
		}

		return outAabb;
	}

	HIPRT_HOST_DEVICE Aabb motionBounds( const Aabb& aabb )
	{
		float3 p0 = aabb.m_min;
		float3 p1 = make_float3( aabb.m_min.x, aabb.m_min.y, aabb.m_max.z );
		float3 p2 = make_float3( aabb.m_min.x, aabb.m_max.y, aabb.m_min.z );
		float3 p3 = make_float3( aabb.m_min.x, aabb.m_max.y, aabb.m_max.z );
		float3 p4 = make_float3( aabb.m_max.x, aabb.m_min.y, aabb.m_max.z );
		float3 p5 = make_float3( aabb.m_max.x, aabb.m_max.y, aabb.m_min.z );
		float3 p6 = make_float3( aabb.m_max.x, aabb.m_max.y, aabb.m_max.z );
		float3 p7 = aabb.m_max;

		Aabb outAabb;
		outAabb.grow( boundPointMotion( p0 ) );
		outAabb.grow( boundPointMotion( p1 ) );
		outAabb.grow( boundPointMotion( p2 ) );
		outAabb.grow( boundPointMotion( p3 ) );
		outAabb.grow( boundPointMotion( p4 ) );
		outAabb.grow( boundPointMotion( p5 ) );
		outAabb.grow( boundPointMotion( p6 ) );
		outAabb.grow( boundPointMotion( p7 ) );
		return outAabb;
	}

  private:
	u32			 m_frameCount;
	const Frame* m_frames;
};

struct HIPRT_ALIGN( 8 ) TransformHeader
{
	u32 m_frameIndex;
	u32 m_frameCount;
};
static_assert( sizeof( TransformHeader ) == 8 );
} // namespace hiprt
