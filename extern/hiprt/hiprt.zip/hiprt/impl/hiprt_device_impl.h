#define HIPRT_DEVICE_H

#include <hiprt/impl/Common.h>

enum
{
	hiprtInvalidValue = ~0u,
};

struct HIPRT_ALIGN( 32 ) hiprtRay
{
	float3 origin;
	float  time;
	float3 direction;
	float  maxT;
};
static_assert( sizeof( hiprtRay ) == 32 );


struct HIPRT_ALIGN( 32 ) hiprtHit
{
	u32	   instanceID;
	u32	   primID;
	float2 uv;
	float3 normal;
	float  t;

	HIPRT_DEVICE bool hasHit() const { return primID != hiprtInvalidValue; }
};
static_assert( sizeof( hiprtHit ) == 32 );

enum hiprtTraversalType
{
	hiprtTraversalTerminateAtAnyHit = 1,	 /*!< 0 or 1 element iterator with
											  any hit along the ray*/
	hiprtTraversalTerminateAtClosestHit = 2, /*!< 0 or 1 element iterator with a
											closest hit along the ray*/
};

enum hiprtTraversalState
{
	hiprtTraversalStateInit,
	hiprtTraversalStateFinished,
	hiprtTraversalStateHit,
	hiprtTraversalStateStackOverflow
};

enum hiprtTraversalHint
{
	hiprtTraversalHintDefault		 = 0,
	hiprtTraversalHintShadowRays	 = 1,
	hiprtTraversalHintReflectionRays = 2
};

struct _hiprtContext;
struct _hiprtCustomFuncTable;

typedef void*				   hiprtDevicePtr;
typedef hiprtDevicePtr		   hiprtGeometry;
typedef hiprtDevicePtr		   hiprtScene;
typedef u32					   hiprtBuildFlags;
typedef u32					   hiprtRayMask;
typedef _hiprtContext*		   hiprtContext;
typedef _hiprtCustomFuncTable* hiprtCustomFuncTable;

#include <hiprt/impl/Aabb.h>
#include <hiprt/impl/BvhNode.h>
#include <hiprt/impl/QrDecomposition.h>
#include <hiprt/impl/Quaternion.h>
#include <hiprt/impl/Ray.h>
#include <hiprt/impl/Transform.h>
#include <hiprt/impl/Triangle.h>
#include <hiprt/hiprt_vec.h>
#include <hiprt/impl/Geometry.h>
#include <hiprt/impl/Math.h>
#include <hiprt/impl/Scene.h>

#if defined( __USE_HWI__ )
extern "C" __device__ float __ocml_native_recip_f32( float );
#endif

typedef bool ( *hiprtIntersectFunc )(
	const hiprtRay& ray, u32 instanceID, u32 primID, const void* data, void* payload, float2& uv, float3& normal, float& t );

typedef bool ( *hiprtFilterFunc )(
	const hiprtRay& ray, u32 instanceID, u32 primID, const void* data, void* payload, float2 uv, float3 normal, float t );

struct hiprtCustomFuncSet
{
	hiprtIntersectFunc intersectFunc;
	const void*		   intersectFuncData;
	hiprtFilterFunc	   filterFunc;
	const void*		   filterFuncData;
};

namespace hiprt
{
template <u32 StackSize>
class PrivateStack
{
  public:
	HIPRT_DEVICE PrivateStack() : m_top( 0u ) {}

	HIPRT_DEVICE int  pop() { return m_stackBuffer[--m_top]; }
	HIPRT_DEVICE void push( int val ) { m_stackBuffer[m_top++] = val; }
	HIPRT_DEVICE bool empty() const { return m_top == 0u; }
	HIPRT_DEVICE int  vacancy() const { return StackSize - m_top; }
	HIPRT_DEVICE void reset() { m_top = 0u; }

  private:
	int m_stackBuffer[StackSize];
	u32 m_top;
};

class GlobalStack
{
  public:
	HIPRT_DEVICE
	GlobalStack( int* globalStackBuffer, u32 globalStackSize, int* sharedStackBuffer = nullptr, u32 sharedStackSize = 0u )
		: m_globalStackSize( globalStackSize ), m_sharedStackSize( sharedStackSize ), m_globalTop( 0u ), m_sharedTop( 0u )
	{
		const u32 threadIndex		= threadIdx.x + threadIdx.y * blockDim.x;
		const u32 warpIndex			= threadIndex / WARP_THREADS;
		const u32 warpThreadIndex	= threadIndex % WARP_THREADS;
		const u32 sharedStackOffset = warpThreadIndex + warpIndex * WARP_THREADS * sharedStackSize;
		const u32 globalStackOffset = warpThreadIndex + ( warpIndex * WARP_THREADS + ( blockIdx.x + blockIdx.y * gridDim.x ) *
																						 ( blockDim.x * blockDim.y ) ) * globalStackSize;
		m_sharedStackBuffer = sharedStackBuffer + sharedStackOffset;
		m_globalStackBuffer = globalStackBuffer + globalStackOffset;
	}

	HIPRT_DEVICE int pop()
	{
		if ( m_globalTop > 0 )
		{
			m_globalTop -= WARP_THREADS;
			return m_globalStackBuffer[m_globalTop];
		}
		else
		{
			m_sharedTop -= WARP_THREADS;
			return m_sharedStackBuffer[m_sharedTop];

		}
	}

	HIPRT_DEVICE void push( int val )
	{
		if ( m_sharedTop < m_sharedStackSize * WARP_THREADS )
		{
			m_sharedStackBuffer[m_sharedTop] = val;
			m_sharedTop += WARP_THREADS;
		}
		else
		{
			m_globalStackBuffer[m_globalTop] = val;
			m_globalTop += WARP_THREADS;
		}
	}

	HIPRT_DEVICE int vacancy() const 
	{ 
		return m_globalStackSize - ( m_globalTop / WARP_THREADS ) + m_sharedStackSize - ( m_sharedTop / WARP_THREADS );
	}

	HIPRT_DEVICE bool empty() const 
	{
		if ( m_sharedStackSize == 0 )
			return m_globalTop == 0u; 
		else
			return m_sharedTop == 0u; 
	}

	HIPRT_DEVICE void reset()
	{
		m_globalTop = 0u;
		m_sharedTop = 0u;
	}

  private:
	int* m_globalStackBuffer;
	int* m_sharedStackBuffer;
	u32	 m_globalStackSize;
	u32	 m_sharedStackSize;
	u32	 m_globalTop;
	u32	 m_sharedTop;	
};

template <typename Stack>
class TraversalBase
{
  public:
	HIPRT_DEVICE TraversalBase( const hiprtRay& ray, Stack& stack, hiprtTraversalHint hint, void* payload )
		: m_ray( ray ), m_stack( stack ), m_payload( payload )
	{
		m_state = hiprtTraversalStateInit;
#if defined( __USE_HWI__ )
		packDescriptor( m_descriptor, nullptr, u32( hint ) );
#endif
	}

#if defined( __USE_HWI__ )
	HIPRT_DEVICE void packDescriptor(
		uint4&		descriptor,
		const void* nodes			 = nullptr,
		u64			boxSortHeuristic = 0u,
		u64			boxGrowUlp		 = 6u,
		u64			boxSortEnabled	 = 1u,
		u64			size			 = -1ull,
		u64			bigPage			 = 0u,
		u64			llcNoalloc		 = 0u );
#endif

	HIPRT_DEVICE hiprtTraversalState getCurrentState() { return m_state; }

	HIPRT_DEVICE bool
	testInternalNode( const Ray& ray, const float3& invD, const float3& oxInvD, BoxNode* node, int& nodeIndex );

  protected:
	hiprtRay			m_ray;
	hiprtTraversalState m_state;
	Stack&				m_stack;
	void*				m_payload;
#if defined( __USE_HWI__ )
	uint4				m_descriptor;
#endif
};

#if defined( __USE_HWI__ )
template <typename Stack>
HIPRT_DEVICE void TraversalBase<Stack>::packDescriptor(
	uint4&		descriptor,
	const void* nodes,
	u64			boxSortHeuristic,
	u64			boxGrowUlp,
	u64			boxSortEnabled,
	u64			size,
	u64			bigPage,
	u64			llcNoalloc )
{
	u64 triangleReturnMode = 1u;
	u64 baseAddress		   = (u64)nodes;
	baseAddress			   = ( baseAddress >> 8ull ) & 0xffffffffffull;
	boxSortHeuristic &= 0x3;
	boxGrowUlp &= 0xff;
	boxSortEnabled &= 0x1;
	size &= 0x3ffffffffffull;
	bigPage &= 1u;
	u64 type = 0x8;
	llcNoalloc &= 0x3;
	*( (u64*)&descriptor.x ) = baseAddress | ( boxSortHeuristic << 53ull ) | ( boxGrowUlp << 55ull ) | ( boxSortEnabled << 63ull );
	*( (u64*)&descriptor.z ) = size | ( bigPage << 59ull ) | ( type << 60ull ) | ( triangleReturnMode << 56ull ) | ( llcNoalloc << 57ull );
}
#endif

template <typename Stack>
HIPRT_DEVICE bool TraversalBase<Stack>::testInternalNode(
	const Ray& ray, const float3& invD, const float3& oxInvD, BoxNode* nodes, int& nodeIndex )
{
#if !defined( __USE_HWI__ )
	BoxNode node = nodes[getNodeAddr( nodeIndex )];
	float2	s0	 = node.m_box0.intersect( invD, oxInvD, ray.m_maxT );
	float2	s1	 = node.m_box1.intersect( invD, oxInvD, ray.m_maxT );
	float2	s2	 = node.m_box2.intersect( invD, oxInvD, ray.m_maxT );
	float2	s3	 = node.m_box3.intersect( invD, oxInvD, ray.m_maxT );

	u32 result[4];
	result[0] = s0.x <= s0.y ? node.m_childIndex0 : hiprtInvalidValue;
	result[1] = s1.x <= s1.y ? node.m_childIndex1 : hiprtInvalidValue;
	result[2] = s2.x <= s2.y ? node.m_childIndex2 : hiprtInvalidValue;
	result[3] = s3.x <= s3.y ? node.m_childIndex3 : hiprtInvalidValue;

#define SORT(childIndexA, childIndexB, distA, distB) if((childIndexB != hiprtInvalidValue && distB < distA) || childIndexA == hiprtInvalidValue) { float t0 = distA; u32 t1 = childIndexA; childIndexA = childIndexB; distA = distB; childIndexB = t1; distB = t0; }

	SORT( result[0], result[2], s0.x, s2.x )
	SORT( result[1], result[3], s1.x, s3.x )
	SORT( result[0], result[1], s0.x, s1.x )
	SORT( result[2], result[3], s2.x, s3.x )
	SORT( result[1], result[2], s1.x, s2.x )
#undef SORT
#else
	auto result = __builtin_amdgcn_image_bvh_intersect_ray_l(
		encodeBaseAddr( nodes, nodeIndex ),
		ray.m_maxT,
		make_float4( ray.m_origin.x, ray.m_origin.y, ray.m_origin.z, ray.m_origin.z ).data,
		make_float4( ray.m_direction.x, ray.m_direction.y, ray.m_direction.z, ray.m_direction.z ).data,
		make_float4( invD.x, invD.y, invD.z, invD.z ).data,
		m_descriptor.data );
#endif
	if ( m_stack.vacancy() < 3 ) { m_state = hiprtTraversalStateStackOverflow; return true; }
	if ( result[3] != hiprtInvalidValue ) m_stack.push( result[3] );
	if ( result[2] != hiprtInvalidValue ) m_stack.push( result[2] );
	if ( result[1] != hiprtInvalidValue ) m_stack.push( result[1] );
	if ( result[0] != hiprtInvalidValue )
	{
		nodeIndex = result[0];
		return true;
	}
	return false;
}

template <typename Stack, typename PrimitiveNode, hiprtTraversalType TraversalType>
class GeomTraversal : public TraversalBase<Stack>
{
  public:
	HIPRT_DEVICE
	GeomTraversal( hiprtGeometry geom, const hiprtRay& ray, Stack& stack );

	HIPRT_DEVICE
	GeomTraversal(
		hiprtGeometry	   geom,
		const hiprtRay&	   ray,
		hiprtCustomFuncSet funcSet,
		Stack&			   stack,
		hiprtTraversalHint hint	   = hiprtTraversalHintDefault,
		void*			   payload = nullptr );

	HIPRT_DEVICE bool testLeafNode(
		const Ray& ray, const float3& invD, int leafIndex, int& hitIndex, float2& hitUv, float3& hitNormal, float& hitT );

	HIPRT_DEVICE hiprtHit getNextHit();

  protected:
	using TraversalBase<Stack>::m_ray;
	using TraversalBase<Stack>::m_state;
	using TraversalBase<Stack>::m_stack;
	using TraversalBase<Stack>::m_payload;
#if defined( __USE_HWI__ )
	using TraversalBase<Stack>::m_descriptor;
#endif

	int				   m_nodeIndex;
	BoxNode*		   m_boxNodes;
	PrimitiveNode*	   m_primNodes;
	hiprtCustomFuncSet m_funcSet;
};

template <typename Stack, typename PrimitiveNode, hiprtTraversalType TraversalType>
HIPRT_DEVICE GeomTraversal<Stack, PrimitiveNode, TraversalType>::GeomTraversal(
	hiprtGeometry geom, const hiprtRay& ray, Stack& stack )
	: TraversalBase<Stack>( ray, stack, hiprtTraversalHintDefault, nullptr ), m_nodeIndex( RootIndex )
{
	GeomHeader* data = (GeomHeader*)geom;
	m_boxNodes		 = data->m_boxNodes;
	m_primNodes		 = (PrimitiveNode*)data->m_primNodes;
	m_stack.reset();
	m_funcSet.intersectFunc = nullptr;
	m_funcSet.filterFunc	= nullptr;
}

template <typename Stack, typename PrimitiveNode, hiprtTraversalType TraversalType>
HIPRT_DEVICE GeomTraversal<Stack, PrimitiveNode, TraversalType>::GeomTraversal(
	hiprtGeometry geom, const hiprtRay& ray, hiprtCustomFuncSet funcSet, Stack& stack, hiprtTraversalHint hint, void* payload )
	: TraversalBase<Stack>( ray, stack, hint, payload ), m_funcSet( funcSet ), m_nodeIndex( RootIndex )
{
	GeomHeader* data = (GeomHeader*)geom;
	m_boxNodes		 = data->m_boxNodes;
	m_primNodes		 = (PrimitiveNode*)data->m_primNodes;
	m_stack.reset();
}

template <typename Stack, typename PrimitiveNode, hiprtTraversalType TraversalType>
HIPRT_DEVICE bool GeomTraversal<Stack, PrimitiveNode, TraversalType>::testLeafNode(
	const Ray& ray, const float3& invD, int leafIndex, int& hitIndex, float2& hitUv, float3& hitNormal, float& hitT )
{
	bool		  hit  = false;
	PrimitiveNode node = m_primNodes[getNodeAddr( leafIndex )];
	if constexpr ( is_same<PrimitiveNode, TriangleNode>::value )
	{
#if !defined( __USE_HWI__ )
		hit = node.m_triangle.intersect( ray, hitUv, hitT );
		if ( hit )
		{
			hitIndex  = node.m_primIndex;
			hitNormal = node.m_triangle.normal();
		}
#else
		auto result = __builtin_amdgcn_image_bvh_intersect_ray_l(
			encodeBaseAddr( m_primNodes, leafIndex ),
			ray.m_maxT,
			make_float4( ray.m_origin.x, ray.m_origin.y, ray.m_origin.z, ray.m_origin.z ).data,
			make_float4( ray.m_direction.x, ray.m_direction.y, ray.m_direction.z, ray.m_direction.z ).data,
			make_float4( invD.x, invD.y, invD.z, invD.z ).data,
			m_descriptor.data );
		float invDenom = __ocml_native_recip_f32( __int_as_float( result[1] ) );
		float t		   = __int_as_float( result[0] ) * invDenom;
		hit			   = t <= ray.m_maxT;
		if ( hit )
		{
			hitT	  = t;
			hitUv.x	  = __int_as_float( result[2] ) * invDenom;
			hitUv.y	  = __int_as_float( result[3] ) * invDenom;
			hitIndex  = node.m_primIndex;
			hitNormal = node.m_triangle.normal();
		}
#endif
	}
	else
	{
		hit = m_funcSet.intersectFunc(
			*( (hiprtRay*)&ray ), hiprtInvalidValue, node.m_primIndex, m_funcSet.intersectFuncData, m_payload, hitUv, hitNormal, hitT );
		if ( hit ) hitIndex = node.m_primIndex;
	}
	return hit;
}

template <typename Stack, typename PrimitiveNode, hiprtTraversalType TraversalType>
HIPRT_DEVICE hiprtHit GeomTraversal<Stack, PrimitiveNode, TraversalType>::getNextHit()
{
	Ray	   ray	  = *( (Ray*)&m_ray );
	float3 invD	  = safeInv( m_ray.direction );
	float3 oxInvD = -m_ray.origin * invD;

	int leafIndex = hiprtInvalidValue;
	int nodeIndex = m_nodeIndex;
	if ( isLeafNode( nodeIndex ) )
	{
		leafIndex = nodeIndex;
		nodeIndex = m_stack.pop();
	}
	int	   hitIndex		= hiprtInvalidValue;
	int	   hitPrimIndex = hiprtInvalidValue;
	float  hitT			= 0.0f;
	float2 hitUv		= make_float2( 0.0f, 0.0f );
	float3 hitNormal;

	if ( m_stack.empty() ) m_stack.push( hiprtInvalidValue );

	while ( nodeIndex != hiprtInvalidValue || leafIndex != hiprtInvalidValue )
	{
		while ( isInternalNode( nodeIndex ) )
		{
			if ( !this->testInternalNode( ray, invD, oxInvD, m_boxNodes, nodeIndex ) ) nodeIndex = m_stack.pop();

			if ( m_state == hiprtTraversalStateStackOverflow )
				return hiprtHit{ hiprtInvalidValue, hiprtInvalidValue, { 0.0f, 0.0f }, { 0.0f, 0.0f, 0.0f }, -1.0f };

			if ( isLeafNode( nodeIndex ) && leafIndex == hiprtInvalidValue )
			{
				leafIndex = nodeIndex;
				nodeIndex = m_stack.pop();
			}

			if ( !__any( leafIndex == hiprtInvalidValue ) ) break;
		}

		while ( leafIndex != hiprtInvalidValue )
		{
			if ( testLeafNode( ray, invD, leafIndex, hitPrimIndex, hitUv, hitNormal, hitT ) )
			{
				if ( m_funcSet.filterFunc == nullptr || !m_funcSet.filterFunc(
						*( (hiprtRay*)&ray ),
						hiprtInvalidValue,
						hitPrimIndex,
						m_funcSet.filterFuncData,
						m_payload,
						hitUv,
						hitNormal,
						hitT ) )
				{
					if constexpr ( TraversalType == hiprtTraversalTerminateAtAnyHit )
					{
						m_nodeIndex = nodeIndex;
						m_state		= hiprtTraversalStateHit;
						return hiprtHit{ hiprtInvalidValue, (u32)hitPrimIndex, hitUv, hitNormal, hitT };
					}
					else
					{
						hitIndex   = leafIndex;
						ray.m_maxT = hitT;
					}
				}
			}

			leafIndex = hiprtInvalidValue;
			if ( isLeafNode( nodeIndex ) )
			{
				leafIndex = nodeIndex;
				nodeIndex = m_stack.pop();
			}
		}
	}

	hiprtHit result{ hiprtInvalidValue, hiprtInvalidValue, { 0.0f, 0.0f }, { 0.0f, 0.0f, 0.0f }, -1.0f };
	if ( hitIndex != hiprtInvalidValue )
	{
		result.primID = m_primNodes[getNodeAddr( hitIndex )].m_primIndex;
		result.uv	  = hitUv;
		result.normal = hitNormal;
		result.t	  = hitT;
	}
	if ( m_state != hiprtTraversalStateStackOverflow )
		m_state = hiprtTraversalStateFinished;
	return result;
}

template <typename Stack, hiprtTraversalType TraversalType>
class SceneTraversal : public TraversalBase<Stack>
{
  public:
	HIPRT_DEVICE SceneTraversal( hiprtScene scene, const hiprtRay& ray, hiprtRayMask mask, Stack& stack );

	HIPRT_DEVICE SceneTraversal(
		hiprtScene			 scene,
		const hiprtRay&		 ray,
		hiprtRayMask		 mask,
		hiprtCustomFuncTable funcTable,
		Stack&				 stack,
		hiprtTraversalHint	 hint	 = hiprtTraversalHintDefault,
		void*				 payload = nullptr );

	HIPRT_DEVICE void transformRay( Ray& ray, float3& invD, float3& oxInvD, const InstanceNode& node ) const;

	HIPRT_DEVICE void restoreRay( Ray& ray, float3& invD, float3& oxInvD ) const;

	HIPRT_DEVICE bool testLeafNode(
		TriangleNode* primNodes,
		const Ray&	  ray,
		const float3& invD,
		int			  leafIndex,
		int			  shapeId,
		int&		  hitIndex,
		float2&		  hitUv,
		float3&		  hitNormal,
		float&		  hitT,
		u32&		  funcSetIndex );

	HIPRT_DEVICE hiprtHit getNextHit();

  protected:
	using TraversalBase<Stack>::m_ray;
	using TraversalBase<Stack>::m_state;
	using TraversalBase<Stack>::m_stack;
	using TraversalBase<Stack>::m_payload;
#if defined( __USE_HWI__ )
	using TraversalBase<Stack>::m_descriptor;
#endif

	int					 m_nodeIndex;
	int					 m_instanceIndex;
	BoxNode*			 m_boxNodes;
	InstanceNode*		 m_instanceNodes;
	GeomHeader**		 m_geoms;
	Frame*				 m_frames;
	hiprtRayMask		 m_mask;
	hiprtCustomFuncTable m_funcTable;
};

template <typename Stack, hiprtTraversalType TraversalType>
HIPRT_DEVICE SceneTraversal<Stack, TraversalType>::SceneTraversal( hiprtScene scene, const hiprtRay& ray, hiprtRayMask mask, Stack& stack )
	: TraversalBase<Stack>( ray, stack, hiprtTraversalHintDefault, nullptr ), m_funcTable( nullptr ), m_mask( mask ),
	  m_instanceIndex( hiprtInvalidValue ), m_nodeIndex( RootIndex )
{
	SceneHeader* data = (SceneHeader*)scene;
	m_boxNodes		  = data->m_boxNodes;
	m_instanceNodes	  = data->m_primNodes;
	m_geoms			  = data->m_geoms;
	m_frames		  = data->m_frames;
	m_stack.reset();
}

template <typename Stack, hiprtTraversalType TraversalType>
HIPRT_DEVICE SceneTraversal<Stack, TraversalType>::SceneTraversal(
	hiprtScene			 scene,
	const hiprtRay&		 ray,
	hiprtRayMask		 mask,
	hiprtCustomFuncTable funcTable,
	Stack&				 stack,
	hiprtTraversalHint	 hint,
	void*				 payload )
	: TraversalBase<Stack>( ray, stack, hint, payload ), m_funcTable( funcTable ), m_mask( mask ), m_instanceIndex( hiprtInvalidValue ),
	  m_nodeIndex( RootIndex )
{
	SceneHeader* data = (SceneHeader*)scene;
	m_boxNodes		  = data->m_boxNodes;
	m_instanceNodes	  = data->m_primNodes;
	m_geoms			  = data->m_geoms;
	m_frames		  = data->m_frames;
	m_stack.reset();
}

template <typename Stack, hiprtTraversalType TraversalType>
HIPRT_DEVICE void SceneTraversal<Stack, TraversalType>::transformRay(
	Ray& ray, float3& invD, float3& oxInvD, const InstanceNode& node ) const
{
	Transform tr( m_frames + node.m_frameIndex, node.m_frameCount );
	ray	   = tr.transformRay( ray );
	invD   = safeInv( ray.m_direction );
	oxInvD = -ray.m_origin * invD;
}

template <typename Stack, hiprtTraversalType TraversalType>
HIPRT_DEVICE void
SceneTraversal<Stack, TraversalType>::restoreRay( Ray& ray, float3& invD, float3& oxInvD ) const
{
	ray.m_origin	= m_ray.origin;
	ray.m_direction = m_ray.direction;
	invD			= safeInv( m_ray.direction );
	oxInvD			= -m_ray.origin * invD;
}

template <typename Stack, hiprtTraversalType TraversalType>
HIPRT_DEVICE bool SceneTraversal<Stack, TraversalType>::testLeafNode(
	TriangleNode* primNodes,
	const Ray&	  ray,
	const float3& invD,
	int			  leafIndex,
	int			  instanceId,
	int&		  hitIndex,
	float2&		  hitUv,
	float3&		  hitNormal,
	float&		  hitT,
	u32&		  funcSetIndex )
{
	bool			  hit		  = false;
		
	hiprtCustomFuncSet* funcTable = (hiprtCustomFuncSet*)m_funcTable;
	if ( funcSetIndex == hiprtInvalidValue || funcTable[funcSetIndex].intersectFunc == nullptr )
	{
		TriangleNode node = ( (TriangleNode*)primNodes )[getNodeAddr( leafIndex )];
#if !defined( __USE_HWI__ )
		hit = node.m_triangle.intersect( ray, hitUv, hitT );
		if ( hit )
		{
			hitIndex  = node.m_primIndex;
			hitNormal = node.m_triangle.normal();
		}
#else
		auto result = __builtin_amdgcn_image_bvh_intersect_ray_l(
			encodeBaseAddr( primNodes, leafIndex ),
			ray.m_maxT,
			make_float4( ray.m_origin.x, ray.m_origin.y, ray.m_origin.z, ray.m_origin.z ).data,
			make_float4( ray.m_direction.x, ray.m_direction.y, ray.m_direction.z, ray.m_direction.z ).data,
			make_float4( invD.x, invD.y, invD.z, invD.z ).data,
			m_descriptor.data );
		float invDenom = __ocml_native_recip_f32( __int_as_float( result[1] ) );
		float t		   = __int_as_float( result[0] ) * invDenom;
		hit			   = t <= ray.m_maxT;
		if ( hit )
		{
			hitT	  = t;
			hitUv.x	  = __int_as_float( result[2] ) * invDenom;
			hitUv.y	  = __int_as_float( result[3] ) * invDenom;
			hitIndex  = node.m_primIndex;
			hitNormal = node.m_triangle.normal();
		}
#endif
	}
	else
	{
		CustomNode node = ( (CustomNode*)primNodes )[getNodeAddr( leafIndex )];
		hit				= funcTable[funcSetIndex].intersectFunc(
			*( (hiprtRay*)&ray ),
			instanceId,
			node.m_primIndex,
			funcTable[funcSetIndex].intersectFuncData,
			m_payload,
			hitUv,
			hitNormal,
			hitT );
		if ( hit ) hitIndex = node.m_primIndex;
	}
	return hit;
}

template <typename Stack, hiprtTraversalType TraversalType>
HIPRT_DEVICE hiprtHit SceneTraversal<Stack, TraversalType>::getNextHit()
{
	int instanceId	  = hiprtInvalidValue;
	int nodeIndex	  = m_nodeIndex;
	int instanceIndex = m_instanceIndex;

	BoxNode*	  nodes			= m_boxNodes;
	TriangleNode* primNodes		= nullptr;
	u32			  funcSetIndex	= hiprtInvalidValue;

	Ray	   ray = *(Ray*)&m_ray;
	float3 invD, oxInvD;
	if ( instanceIndex == hiprtInvalidValue )
	{
		restoreRay( ray, invD, oxInvD );
	}
	else
	{
		InstanceNode node = m_instanceNodes[getNodeAddr( instanceIndex )];
		instanceId		  = node.m_primIndex;
		transformRay( ray, invD, oxInvD, node );

		nodes		 = m_geoms[instanceId]->m_boxNodes;
		primNodes	 = (TriangleNode*)m_geoms[instanceId]->m_primNodes;
		funcSetIndex = m_geoms[instanceId]->m_funcSetIndex;
	}

	int	   hitInstanceId	= hiprtInvalidValue;
	int	   hitInstanceIndex = hiprtInvalidValue;
	int	   hitPrimIndex		= hiprtInvalidValue;
	float  hitT				= 0.0f;
	float2 hitUv			= make_float2( 0.0f, 0.0f );
	float3 hitNormal;

	if ( m_stack.empty() ) m_stack.push( hiprtInvalidValue );

	while ( nodeIndex != hiprtInvalidValue && m_state != hiprtTraversalStateStackOverflow )
	{
		if ( isInternalNode( nodeIndex ) )
		{
			if ( this->testInternalNode( ray, invD, oxInvD, nodes, nodeIndex ) ) 
				continue;
		}
		else 
		{
			if ( instanceId != hiprtInvalidValue )
			{
				
				if ( testLeafNode( primNodes, ray, invD, nodeIndex, instanceId, hitPrimIndex, hitUv, hitNormal, hitT, funcSetIndex ) )
				{
					hiprtCustomFuncSet* funcTable = (hiprtCustomFuncSet*)m_funcTable;
					if ( funcSetIndex == hiprtInvalidValue || funcTable == nullptr || funcTable[funcSetIndex].filterFunc == nullptr ||
						 !funcTable[funcSetIndex].filterFunc(
							 *( (hiprtRay*)&ray ),
							 instanceId,
							 hitPrimIndex,
							 funcTable[funcSetIndex].filterFuncData,
							 m_payload,
							 hitUv,
							 hitNormal,
							 hitT ) )
					{
						if constexpr ( TraversalType == hiprtTraversalTerminateAtAnyHit )
						{
							m_nodeIndex		= m_stack.pop();
							m_instanceIndex = instanceIndex;
							m_state			= hiprtTraversalStateHit;
							if ( m_nodeIndex == hiprtInvalidValue && !m_stack.empty() )
							{
								m_instanceIndex = hiprtInvalidValue;
								m_nodeIndex		= m_stack.pop();
							}
							InstanceNode& node = m_instanceNodes[getNodeAddr( instanceIndex )];
							Transform	  tr( m_frames + node.m_frameIndex, node.m_frameCount );
							hitNormal = tr.transformNormal( hitNormal, ray.m_time );
							return hiprtHit{ (u32)instanceId, (u32)hitPrimIndex, hitUv, hitNormal, hitT };
						}
						else
						{
							hitInstanceId	 = instanceId;
							hitInstanceIndex = instanceIndex;
							ray.m_maxT		 = hitT;
						}
					}
				}
			}
			else
			{
				InstanceNode node = m_instanceNodes[getNodeAddr( nodeIndex )];
				if ( node.m_mask & m_mask )
				{
					if ( m_stack.vacancy() < 1 )
					{
						m_state = hiprtTraversalStateStackOverflow;
						continue;
					}
					m_stack.push( hiprtInvalidValue );
					instanceIndex = nodeIndex;
					nodeIndex	  = RootIndex;
					instanceId	  = node.m_primIndex;
					nodes = m_geoms[instanceId]->m_boxNodes;
					primNodes = (TriangleNode*) m_geoms[instanceId]->m_primNodes;
					funcSetIndex = m_geoms[instanceId]->m_funcSetIndex;

					transformRay( ray, invD, oxInvD, node );
					continue;
				}
			}
		}
		nodeIndex = m_stack.pop();
		if ( nodeIndex == hiprtInvalidValue && !m_stack.empty() )
		{
			instanceIndex = hiprtInvalidValue;
			instanceId	  = hiprtInvalidValue;
			nodeIndex	  = m_stack.pop();
			nodes = m_boxNodes;
			restoreRay( ray, invD, oxInvD );
		}
	}

	hiprtHit result{ hiprtInvalidValue, hiprtInvalidValue, { 0.0f, 0.0f }, { 0.0f, 0.0f, 0.0f }, -1.0f };
	if ( hitInstanceId != hiprtInvalidValue )
	{
		InstanceNode node = m_instanceNodes[getNodeAddr( hitInstanceIndex )];
		Transform	 tr( m_frames + node.m_frameIndex, node.m_frameCount );
		result.t		  = hitT;
		result.instanceID = hitInstanceId;
		result.primID	  = hitPrimIndex;
		result.uv		  = hitUv;
		result.normal	  = tr.transformNormal( hitNormal, ray.m_time );
	}
	if ( m_state != hiprtTraversalStateStackOverflow )
		m_state = hiprtTraversalStateFinished;
	return result;
}

template <typename PrimitiveNode, hiprtTraversalType TraversalType>
class GeomTraversalPrivateStack
{
  public:
	static constexpr u32			StackSize = 64u;
	typedef PrivateStack<StackSize> Stack;

	HIPRT_DEVICE GeomTraversalPrivateStack( hiprtGeometry geom, const hiprtRay& ray )
		: m_traversal( geom, ray, m_stack ) {}

	HIPRT_DEVICE GeomTraversalPrivateStack(
		hiprtGeometry	   geom,
		const hiprtRay&	   ray,
		hiprtCustomFuncSet funcSet,
		hiprtTraversalHint hint	   = hiprtTraversalHintDefault,
		void*			   payload = nullptr )
		: m_traversal( geom, ray, funcSet, m_stack, hint, payload ) {}

	HIPRT_DEVICE hiprtHit getNextHit() { return m_traversal.getNextHit(); }

	HIPRT_DEVICE hiprtTraversalState getCurrentState() { return m_traversal.getCurrentState(); }

  private:
	Stack											   m_stack;
	GeomTraversal<Stack, PrimitiveNode, TraversalType> m_traversal;
};

template <hiprtTraversalType TraversalType>
class SceneTraversalPrivateStack
{
  public:
	static constexpr u32			StackSize = 64u;
	typedef PrivateStack<StackSize> Stack;

	HIPRT_DEVICE SceneTraversalPrivateStack( hiprtScene scene, const hiprtRay& ray, hiprtRayMask mask )
		: m_traversal( scene, ray, mask, m_stack ) {}

	HIPRT_DEVICE SceneTraversalPrivateStack(
		hiprtScene			 scene,
		const hiprtRay&		 ray,
		hiprtRayMask		 mask,
		hiprtCustomFuncTable funcTable,
		hiprtTraversalHint	 hint	 = hiprtTraversalHintDefault,
		void*				 payload = nullptr )
		: m_traversal( scene, ray, mask, funcTable, m_stack, hint, payload ) {}

	HIPRT_DEVICE hiprtHit getNextHit() { return m_traversal.getNextHit(); }

	HIPRT_DEVICE hiprtTraversalState getCurrentState() { return m_traversal.getCurrentState(); }

  private:
	Stack								 m_stack;
	SceneTraversal<Stack, TraversalType> m_traversal;
};
}; // namespace hiprt

typedef hiprt::PrivateStack<48>	 hiprtPrivateStack48;
typedef hiprt::PrivateStack<64>	 hiprtPrivateStack64;
typedef hiprt::PrivateStack<128> hiprtPrivateStack128;
typedef hiprt::GlobalStack		 hiprtGlobalStack;

template <u32 StackSize> using hiprtCustomPrivateStack = hiprt::PrivateStack<StackSize>;

typedef hiprt::GeomTraversal<hiprt::PrivateStack<48>, hiprt::TriangleNode, hiprtTraversalTerminateAtClosestHit>  hiprtGeomTraversalClosestPrivateStack48;
typedef hiprt::GeomTraversal<hiprt::PrivateStack<64>, hiprt::TriangleNode, hiprtTraversalTerminateAtClosestHit>  hiprtGeomTraversalClosestPrivateStack64;
typedef hiprt::GeomTraversal<hiprt::PrivateStack<128>, hiprt::TriangleNode, hiprtTraversalTerminateAtClosestHit> hiprtGeomTraversalClosestPrivateStack128;
typedef hiprt::GeomTraversal<hiprt::GlobalStack, hiprt::TriangleNode, hiprtTraversalTerminateAtClosestHit>  hiprtGeomTraversalClosestGlobalStack;

typedef hiprt::GeomTraversal<hiprt::PrivateStack<48>, hiprt::CustomNode, hiprtTraversalTerminateAtClosestHit>  hiprtGeomCustomTraversalClosestPrivateStack48;
typedef hiprt::GeomTraversal<hiprt::PrivateStack<64>, hiprt::CustomNode, hiprtTraversalTerminateAtClosestHit>  hiprtGeomCustomTraversalClosestPrivateStack64;
typedef hiprt::GeomTraversal<hiprt::PrivateStack<128>, hiprt::CustomNode, hiprtTraversalTerminateAtClosestHit> hiprtGeomCustomTraversalClosestPrivateStack128;
typedef hiprt::GeomTraversal<hiprt::GlobalStack, hiprt::CustomNode, hiprtTraversalTerminateAtClosestHit>   hiprtGeomCustomTraversalClosestGlobalStack;

typedef hiprt::SceneTraversal<hiprt::PrivateStack<48>, hiprtTraversalTerminateAtClosestHit>  hiprtSceneTraversalClosestPrivateStack48;
typedef hiprt::SceneTraversal<hiprt::PrivateStack<64>, hiprtTraversalTerminateAtClosestHit>  hiprtSceneTraversalClosestPrivateStack64;
typedef hiprt::SceneTraversal<hiprt::PrivateStack<128>, hiprtTraversalTerminateAtClosestHit> hiprtSceneTraversalClosestPrivateStack128;
typedef hiprt::SceneTraversal<hiprt::GlobalStack, hiprtTraversalTerminateAtClosestHit>  hiprtSceneTraversalClosestGlobalStack;

typedef hiprt::GeomTraversal<hiprt::PrivateStack<48>, hiprt::TriangleNode, hiprtTraversalTerminateAtAnyHit>  hiprtGeomTraversalAnyHitPrivateStack48;
typedef hiprt::GeomTraversal<hiprt::PrivateStack<64>, hiprt::TriangleNode, hiprtTraversalTerminateAtAnyHit>  hiprtGeomTraversalAnyHitPrivateStack64;
typedef hiprt::GeomTraversal<hiprt::PrivateStack<128>, hiprt::TriangleNode, hiprtTraversalTerminateAtAnyHit> hiprtGeomTraversalAnyHitPrivateStack128;
typedef hiprt::GeomTraversal<hiprt::GlobalStack, hiprt::TriangleNode, hiprtTraversalTerminateAtAnyHit>   hiprtGeomTraversalAnyHitGlobalStack;

typedef hiprt::GeomTraversal<hiprt::PrivateStack<48>, hiprt::CustomNode, hiprtTraversalTerminateAtAnyHit>  hiprtGeomCustomTraversalAnyHitPrivateStack48;
typedef hiprt::GeomTraversal<hiprt::PrivateStack<64>, hiprt::CustomNode, hiprtTraversalTerminateAtAnyHit>  hiprtGeomCustomTraversalAnyHitPrivateStack64;
typedef hiprt::GeomTraversal<hiprt::PrivateStack<128>, hiprt::CustomNode, hiprtTraversalTerminateAtAnyHit> hiprtGeomCustomTraversalAnyHitPrivateStack128;
typedef hiprt::GeomTraversal<hiprt::GlobalStack, hiprt::CustomNode, hiprtTraversalTerminateAtAnyHit>  hiprtGeomCustomTraversalAnyHitGlobalStack;

typedef hiprt::SceneTraversal<hiprt::PrivateStack<48>, hiprtTraversalTerminateAtAnyHit>  hiprtSceneTraversalAnyHitPrivateStack48;
typedef hiprt::SceneTraversal<hiprt::PrivateStack<64>, hiprtTraversalTerminateAtAnyHit>  hiprtSceneTraversalAnyHitPrivateStack64;
typedef hiprt::SceneTraversal<hiprt::PrivateStack<128>, hiprtTraversalTerminateAtAnyHit> hiprtSceneTraversalAnyHitPrivateStack128;
typedef hiprt::SceneTraversal<hiprt::GlobalStack, hiprtTraversalTerminateAtAnyHit>  hiprtSceneTraversalAnyHitGlobalStack;

typedef hiprt::GeomTraversalPrivateStack<hiprt::TriangleNode, hiprtTraversalTerminateAtAnyHit>	   hiprtGeomTraversalAnyHit;
typedef hiprt::GeomTraversalPrivateStack<hiprt::TriangleNode, hiprtTraversalTerminateAtClosestHit> hiprtGeomTraversalClosest;

typedef hiprt::GeomTraversalPrivateStack<hiprt::CustomNode, hiprtTraversalTerminateAtAnyHit>     hiprtGeomCustomTraversalAnyHit;
typedef hiprt::GeomTraversalPrivateStack<hiprt::CustomNode, hiprtTraversalTerminateAtClosestHit> hiprtGeomCustomTraversalClosest;

typedef hiprt::SceneTraversalPrivateStack<hiprtTraversalTerminateAtAnyHit>	   hiprtSceneTraversalAnyHit;
typedef hiprt::SceneTraversalPrivateStack<hiprtTraversalTerminateAtClosestHit> hiprtSceneTraversalClosest;

template <typename hiprtStack> using hiprtGeomTraversalClosestCustomStack = hiprt::GeomTraversal<hiprtStack, hiprt::TriangleNode, hiprtTraversalTerminateAtClosestHit>;
template <typename hiprtStack> using hiprtGeomTraversalAnyHitCustomStack = hiprt::GeomTraversal<hiprtStack, hiprt::TriangleNode, hiprtTraversalTerminateAtAnyHit>;

template <typename hiprtStack> using hiprtGeomCustomTraversalClosestCustomStack = hiprt::GeomTraversal<hiprtStack, hiprt::CustomNode, hiprtTraversalTerminateAtClosestHit>;
template <typename hiprtStack> using hiprtGeomCustomTraversalAnyHitCustomStack = hiprt::GeomTraversal<hiprtStack, hiprt::CustomNode, hiprtTraversalTerminateAtAnyHit>;

template <typename hiprtStack> using hiprtSceneTraversalClosestCustomStack = hiprt::SceneTraversal<hiprtStack, hiprtTraversalTerminateAtClosestHit>;
template <typename hiprtStack> using hiprtSceneTraversalAnyHitCustomStack = hiprt::SceneTraversal<hiprtStack, hiprtTraversalTerminateAtAnyHit>;
