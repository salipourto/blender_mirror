#pragma once
#include <hiprt/impl/Math.h>

namespace hiprt
{
HIPRT_HOST_DEVICE HIPRT_INLINE float4 qtFromAxisAngle( const float4& axisAngle )
{
	float3 axis	 = normalize( make_float3( axisAngle ) );
	float  angle = axisAngle.w;

	float4 q;
	q.x = axis.x * sinf( angle / 2.0f );
	q.y = axis.y * sinf( angle / 2.0f );
	q.z = axis.z * sinf( angle / 2.0f );
	q.w = cosf( angle / 2.0f );
	return q;
}

HIPRT_HOST_DEVICE HIPRT_INLINE float4 qtToAxisAngle( const float4& q )
{
	float3 axis = make_float3( q );
	float  norm = sqrtf( dot( axis, axis ) );
	if ( norm == 0.0f ) return make_float4( 0.0f, 0.0f, 1.0f, 0.0f );
	float angle = 2.0f * atan2f( norm, q.w );
	return make_float4( axis / norm, angle );
}

HIPRT_HOST_DEVICE HIPRT_INLINE float4 qtFromRotationMatrix( const float R[3][3] ) 
{
	float tr = R[0][0] + R[1][1] + R[2][2];
	float4 q;

	if ( tr > 0.0f )
	{
		float S = sqrtf( tr + 1.0f ) * 2.0f;
		q.w		= 0.25f * S;
		q.x		= ( R[2][1] - R[1][2] ) / S;
		q.y		= ( R[0][2] - R[2][0] ) / S;
		q.z		= ( R[1][0] - R[0][1] ) / S;
	}
	else if ( ( R[0][0] > R[1][1] ) & ( R[0][0] > R[2][2] ) )
	{
		float S = sqrtf( 1.0f + R[0][0] - R[1][1] - R[2][2] ) * 2.0f;
		q.w		= ( R[2][1] - R[1][2] ) / S;
		q.x		= 0.25f * S;
		q.y		= ( R[0][1] + R[1][0] ) / S;
		q.z		= ( R[0][2] + R[2][0] ) / S;
	}
	else if ( R[1][1] > R[2][2] )
	{
		float S = sqrtf( 1.0f + R[1][1] - R[0][0] - R[2][2] ) * 2.0f;
		q.w		= ( R[0][2] - R[2][0] ) / S;
		q.x		= ( R[0][1] + R[1][0] ) / S;
		q.y		= 0.25f * S;
		q.z		= ( R[1][2] + R[2][1] ) / S;
	}
	else
	{
		float S = sqrtf( 1.0f + R[2][2] - R[0][0] - R[1][1] ) * 2.0f;
		q.w		= ( R[1][0] - R[0][1] ) / S;
		q.x		= ( R[0][2] + R[2][0] ) / S;
		q.y		= ( R[1][2] + R[2][1] ) / S;
		q.z		= 0.25f * S;
	}
	return q;
}

HIPRT_HOST_DEVICE HIPRT_INLINE void qtToRotationMatrix( const float4& q, float R[3][3] )
{
	float4 q2 = make_float4( q.x * q.x, q.y * q.y, q.z * q.z, 0.0f );

	R[0][0] = 1 - 2 * q2.y - 2 * q2.z;
	R[0][1] = 2 * q.x * q.y - 2 * q.w * q.z;
	R[0][2] = 2 * q.x * q.z + 2 * q.w * q.y;

	R[1][0] = 2 * q.x * q.y + 2 * q.w * q.z;
	R[1][1] = 1 - 2 * q2.x - 2 * q2.z;
	R[1][2] = 2 * q.y * q.z - 2 * q.w * q.x;

	R[2][0] = 2 * q.x * q.z - 2 * q.w * q.y;
	R[2][1] = 2 * q.y * q.z + 2 * q.w * q.x;
	R[2][2] = 1 - 2 * q2.x - 2 * q2.y;
}

HIPRT_HOST_DEVICE HIPRT_INLINE float4 qtGetIdentity( void ) { return make_float4( 0.0f, 0.0f, 0.0f, 1.0f ); }

HIPRT_HOST_DEVICE HIPRT_INLINE float qtDot( const float4& q0, const float4& q1 )
{
	return q0.x * q1.x + q0.y * q1.y + q0.z * q1.z + q0.w * q1.w;
}

HIPRT_HOST_DEVICE HIPRT_INLINE float4 qtNormalize( const float4& q ) { return q / sqrtf( qtDot( q, q ) ); }

HIPRT_HOST_DEVICE HIPRT_INLINE float4 qtMul( const float4& a, const float4& b )
{
	float4 ans;
	ans = make_float4( cross( make_float3( a ), make_float3( b ) ), 0.0f );
	// ans += a.w * b + b.w * a;
	ans = ans + make_float4( a.w * b.x, a.w * b.y, a.w * b.z, a.w * b.w ) +
		  make_float4( b.w * a.x, b.w * a.y, b.w * a.z, b.w * a.w );
	ans.w = a.w * b.w - dot( make_float3( a ), make_float3( b ) );
	return ans;
}

HIPRT_HOST_DEVICE HIPRT_INLINE float4 qtInvert( const float4& q )
{
	float4 ans;
	ans	  = -q;
	ans.w = q.w;
	return ans;
}

HIPRT_HOST_DEVICE HIPRT_INLINE float3 qtRotate( const float4& q, const float3& p )
{
	float4 qp	= make_float4( p, 0.0f );
	float4 qInv = qtInvert( q );
	float4 out	= qtMul( qtMul( q, qp ), qInv );
	return make_float3( out );
}

HIPRT_HOST_DEVICE HIPRT_INLINE float3 qtInvRotate( const float4& q, const float3& p ) { return qtRotate( qtInvert( q ), p ); }

HIPRT_HOST_DEVICE HIPRT_INLINE float4 qtMix( float4 v0, float4 v1, float t )
{
	// Only unit quaternions are valid rotations.
	// Normalize to avoid undefined behavior.
	v0 = qtNormalize( v0 );
	v1 = qtNormalize( v1 );

	// Compute the cosine of the angle between the two vectors.
	float dot = qtDot( v0, v1 );

	// If the dot product is negative, slerp won't take
	// the shorter path. Note that v1 and -v1 are equivalent when
	// the negation is applied to all four components. Fix by
	// reversing one quaternion.
	if ( dot < 0.0f )
	{
		v1	= -v1;
		dot = -dot;
	}

	const float DOT_THRESHOLD = 0.9995;
	if ( dot > DOT_THRESHOLD )
	{
		// If the inputs are too close for comfort, linearly interpolate
		// and normalize the result.

		float4 result = v0 + ( v1 - v0 ) * t;
		result		  = qtNormalize( result );
		return result;
	}

	// Since dot is in range [0, DOT_THRESHOLD], acos is safe
	float theta_0	  = acosf( dot );	 // theta_0 = angle between input vectors
	float theta		  = theta_0 * t;	 // theta = angle between v0 and result
	float sin_theta	  = sinf( theta );	 // compute this value only once
	float sin_theta_0 = sinf( theta_0 ); // compute this value only once

	float s0 = cosf( theta ) - dot * sin_theta / sin_theta_0; // == sin(theta_0 - theta) / sin(theta_0)
	float s1 = sin_theta / sin_theta_0;

	return ( v0 * s0 ) + ( v1 * s1 );
}
}
