#pragma once
#include <hiprt/impl/BvhNode.h>

namespace hiprt
{
struct GeomHeader
{
	BoxNode* m_boxNodes;
	void*	 m_primNodes;
	u32		 m_funcSetIndex;
	size_t	 m_size;
};
} // namespace hiprt
